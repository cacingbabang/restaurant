<?php

include "../config.php";

function register($data)
{
    global $connection;
    $username = $data["username"];
    $password = $data["password"];
    mysqli_query($connection,"INSERT INTO tb_user VALUES('','$username','$password','user')");
    return mysqli_affected_rows($connection);
}

if(isset($_POST["submit"]))
{
    if(register($_POST) > 0)
    {
        echo"
        <script>
            alert('register berhasil')
            document.location.href = 'login.php'
        </script>
        ";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body id="bg-login">
    <div class="box-login">
    <form action="" method="post">
        <h2>Register</h2>
            <input type="text" name="username" id="" placeholder="username" class="input-control" placeholder="username">
            <input type="password" name="password" id="" placeholder="password" class="input-control" placeholder="username">
            <button type="submit" name="submit">submit</button>
    </form>
</body>
</html>