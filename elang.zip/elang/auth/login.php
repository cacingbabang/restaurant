<?php

include "../config.php";
session_start();

if(isset($_POST["submit"]))
{
    $username = $_POST["username"];
    $password = $_POST["password"];

    $user = mysqli_query($connection,"SELECT * FROM tb_user WHERE username = '$username' AND password = '$password' ");
    $data = mysqli_fetch_assoc($user);
    if(mysqli_num_rows($user) === 1)
    {
        if ($data["level"] == "admin") {
            $_SESSION["admin"] = $username;
            echo "
            <script>
                document.location.href = '../admin/user/index.php'
                alert('berhasil login')
            </script>
            ";
        }else if($data["level"] == "user"){
            $_SESSION["user"] = $username;
            echo "
            <script>
                document.location.href = '../user/index.php'
                alert('berhasil login')
            </script>
            ";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body id="bg-login">
    <div class="box-login">
        <form action="" method="post">
            <h2>login</h2>
            <input type="text" name="username" id="" class="input-control" placeholder="username">
            <input type="password" name="password" id="" class="input-control" placeholder="password">
            <button type="submit" name="submit">Login</button>
            <br><br>
            <h3 class="title">Anda Lupa Password? Tanya Admin!</h3>
            <br><br>
            <div class="button-regis">
            <a href="../auth/register.php">Register</a>
            </div>
        </form>
</body>
</html>