<?php

include "../config.php";
session_start();
$id = $_GET["id_menu"];
if($_SESSION["admin"] == "" )
{
    echo "
    <script>
        alert('harap login terlebih dahulu')
        document.location.href = '../auth/login.php'
    </script>
    ";
}

$menus = mysqli_query($connection,"SELECT * from tb_menu where id_menu = $id");
$menu = mysqli_fetch_assoc($menus);

function imageMenu(){

    $nameFile = $_FILES["image_menu"]["name"];
    $tempName = $_FILES["image_menu"]["tmp_name"];
    $error = $_FILES["image_menu"]["error"];

    // check if no images are uploaded
    if( $error === 4 ){
        echo "please upload image!";
    }

    // check extension image
    $extension = ["jpg","png","jpeg","jfif"];
    $extensionImage = explode(".",$nameFile);
    $extensionImage = strtolower(end($extensionImage));
    
    if( !in_array($extensionImage,$extension) ){
        echo "this file not image";
    }
    
    // change name image from default to random string
    $newName = uniqid();
    $newName .= ".";
    $newName .= $extensionImage;

    move_uploaded_file($tempName, '../img/menu/' . $newName);

    return $newName;

}

function update($data)
{
    global $connection;
    $id_menu = $data["id_menu"];
    $name = $data["name_menu"];
    $price = $data["price_menu"];
    $image_old = $data["image_old"];

    if($_FILES["image_menu"]["error"] === 4){
        $image = $image_old;
    }else{
        $image = imageMenu();
    }

    mysqli_query($connection,"UPDATE tb_menu SET
        name_menu = '$name',
        price_menu = '$price',
        image_menu = '$image'
        WHERE id_menu = $id_menu
    ");

    return mysqli_affected_rows($connection);
}

if(isset($_POST["submit"]))
{
    if(update($_POST) > 0)
    {
        echo "
        <script>
            document.location.href = 'index.php'
        </script>
        ";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
</head>

<body id="bg-update">
<header>
    <div class="container">
    <h1><a href='../admin/index.php'>Dashboard</a></h1>
            <ul>
                <li><a href="../menu/index.php">Menu</a></li>
                <li><a href="../admin/user/index.php">User</a></li>
                <li><a href="../auth/logout.php">Keluar</a></li>
            </ul>
        </div>
</header>
    <div class="box-menu">
        <form action="" method="post" enctype="multipart/form-data">
        <h3 class="ubah-password">Edit Menu</h3>
            <img src="../img/menu/<?= $menu["image_menu"] ?>" alt="" srcset="" height="150">
            <input type="file" name="image_menu" id=""><br><br>
            <input type="hidden" name="id_menu" value=" <?= $menu["id_menu"] ?>" class="input-control">
            <input type="hidden" name="image_old" value="<?= $menu["image_menu"] ?>" class="input-control">
            <input type="text" name="name_menu" value="<?= $menu["name_menu"] ?>"class="input-control"><br>
            <input type="number" name="price_menu" value="<?= $menu["price_menu"] ?>"class="input-control"><br>
            
            <button type="submit" name="submit">submit</button>
        </form>
    </div>
</body>
</html>