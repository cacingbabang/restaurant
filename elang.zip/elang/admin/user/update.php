<?php

include "../../config.php";
session_start();

$id = $_GET["id_user"];
if($_SESSION["admin"] == "" )
{
    echo "
    <script>
        alert('harap login terlebih dahulu')
        document.location.href = '../../auth/login.php'
    </script>
    ";
}

$users = mysqli_query($connection,"SELECT * FROM tb_user WHERE id_user = $id ");
$user = mysqli_fetch_assoc($users);

function update($data)
{
    global $connection;
    $id = $data["id_user"];
    $username = $data["username"];
    $password = $data["password"];
    $level = $data["level"];

    if($level === ""){
        echo"
        <script>
            alert('harap isi status user')
            document.location.href == '../update.php'
        </script>
        ";
        return false;
    }

    mysqli_query($connection,"UPDATE tb_user SET
        username = '$username',
        password = '$password',
        level = '$level'
        WHERE id_user = $id
    ");

    return mysqli_affected_rows($connection);
}

if(isset($_POST["submit"]))
{
    if(update($_POST) > 0)
    {
        echo "
        <script>
            document.location.href = 'index.php'
        </script>
        ";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="../../css/style.css">
</head>
<body id="bg-update">
<header>
    <div class="container">
    <h1><a href='../admin/index.php'>Dashboard</a></h1>
            <ul>
                <li><a href="../../menu/index.php">Menu</a></li>
                <li><a href="../../admin/user/index.php">User</a></li>
                <li><a href="../auth/logout.php">Keluar</a></li>
            </ul>
        </div>
</header>
 <div class="section">
        <div class="box-menu">
            <form action="" method="post">
            <h3 class="ubah-password">Ubah Profil</h3>
                <input type="hidden" value="<?= $user["id_user"] ?>" name="id_user" class="input-control"></input>
                <input type="text" value="<?= $user["username"] ?>" name="username" class="input-control"></input><br>
                <input type="text" value="<?= $user["password"] ?>" name="password" class="input-control"></input><br>
                <select name="level" id="">
                    
                    <option value="<?= $user["level"] ?>">--</option>
                    <option value="admin">admin</option>
                    <option value="user">user</option>
                </select><br><br><br>
                <button type="submit" name="submit">submit</button>
            </form>
</div>
            </div>
</div> 
</body>
</html>